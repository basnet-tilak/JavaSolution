create
    definer = root@localhost procedure GetEmployeesByDept(IN dept_name varchar(50))
BEGIN
SELECT * FROM employees WHERE department = dept_name;
END;


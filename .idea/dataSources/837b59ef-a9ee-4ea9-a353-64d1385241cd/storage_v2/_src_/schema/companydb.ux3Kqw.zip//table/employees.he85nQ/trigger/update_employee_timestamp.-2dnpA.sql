create definer = root@localhost trigger update_employee_timestamp
    before update
    on employees
    for each row
    SET NEW.updated_at = NOW();


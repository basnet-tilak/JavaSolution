create definer = root@localhost view high_earners as
select `companydb`.`employees`.`name`       AS `name`,
       `companydb`.`employees`.`department` AS `department`,
       `companydb`.`employees`.`salary`     AS `salary`
from `companydb`.`employees`
where (`companydb`.`employees`.`salary` > 80000);

